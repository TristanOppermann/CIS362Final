package com.example.attendancemanagementsystem;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Display_Student_By_Year extends Activity {

	ArrayList<Student_class> studentClassList;
	private ListView listView ;  
	private ArrayAdapter<String> listAdapter;
	String branch;
	String year;
	

	DBAdapter dbAdapter = new DBAdapter(this);
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.__listview_main);

		listView=(ListView)findViewById(R.id.listview);
		final ArrayList<String> studentList = new ArrayList<String>();
		
		 branch=getIntent().getExtras().getString("branch");
		 year =getIntent().getExtras().getString("year");

		studentClassList =dbAdapter.getAllStudentByBranchYear(branch, year);

		for(Student_class studentClass : studentClassList)
		{
			String users = studentClass.getStudent_firstname()+","+ studentClass.getStudent_lastname();
					
			studentList.add(users);
			Log.d("users: ", users); 

		}

		listAdapter = new ArrayAdapter<String>(this, R.layout.view_student_list, R.id.label, studentList);
		listView.setAdapter( listAdapter ); 

		listView.setOnItemLongClickListener(new OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
					final int position, long arg3) {



				AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Display_Student_By_Year.this);

				alertDialogBuilder.setTitle(getTitle()+"decision");
				alertDialogBuilder.setMessage("Are you sure?");

				alertDialogBuilder.setPositiveButton("Yes",new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,int id) {

						studentList.remove(position);
						listAdapter.notifyDataSetChanged();
						listAdapter.notifyDataSetInvalidated();   

						dbAdapter.deleteStudent(studentClassList.get(position).getStudent_id());
						studentClassList =dbAdapter.getAllStudentByBranchYear(branch, year);

						for(Student_class studentClass : studentClassList)
						{
							String users = " FirstName: " + studentClass.getStudent_firstname()+"\nLastname:"+ studentClass.getStudent_lastname();
							studentList.add(users);
							Log.d("users: ", users); 

						}
					}

				});

				alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,int id) {
						// cancel the alert box and put a Toast to the user
						dialog.cancel();
						Toast.makeText(getApplicationContext(), "You choose cancel", 
								Toast.LENGTH_LONG).show();
					}
				});

				AlertDialog alertDialog = alertDialogBuilder.create();
				// show alert
				alertDialog.show();





				return false;
			}
		});




	}



	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
